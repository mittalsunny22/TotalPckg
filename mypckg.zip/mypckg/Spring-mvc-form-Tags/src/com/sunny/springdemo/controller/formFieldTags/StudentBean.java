package com.sunny.springdemo.controller.formFieldTags;

import java.util.LinkedHashMap;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

public class StudentBean {
	
	private String firstName;
	
	//Suppose we want to add validation that value should not be empty then we can use hibernate validator and add below annotation
	@NotBlank(message = "is required")
	private String lastName;
	
	@Min(value = 25, message = "Age should be greater than or equal to 25")
	@Max(value = 50, message = "Age should be less than or equal to 50")
	private int age;
	
	private String country, gender;
	private LinkedHashMap<String, String> countryList, genderList,operatingSystemsList;
	
	private String favouriteLanguage;
	private String[] operatingSystems;

	public StudentBean() {
		// As this will be called first then we can provide select items here
		
		countryList = new LinkedHashMap<String, String>();
		countryList.put("IN", "India");
		countryList.put("US", "United States");
		
		genderList = new LinkedHashMap<String, String>();
		genderList.put("MALE", "Male");
		genderList.put("FEMA", "Female");
		genderList.put("NTSP", "Not Specified");
		
		operatingSystemsList = new LinkedHashMap<String, String>();
		operatingSystemsList.put("WINDOWS", "Windows");
		operatingSystemsList.put("MAC", "Mac");
		operatingSystemsList.put("DOS", "DOS Based");
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public LinkedHashMap<String, String> getCountryList() {
		return countryList;
	}

	public String getFavouriteLanguage() {
		return favouriteLanguage;
	}

	public void setFavouriteLanguage(String favouriteLanguage) {
		this.favouriteLanguage = favouriteLanguage;
	}
	
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public LinkedHashMap<String, String> getGenderList() {
		return genderList;
	}

	public String[] getOperatingSystems() {
		return operatingSystems;
	}

	public void setOperatingSystems(String[] operatingSystems) {
		this.operatingSystems = operatingSystems;
	}

	public LinkedHashMap<String, String> getOperatingSystemsList() {
		return operatingSystemsList;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
}