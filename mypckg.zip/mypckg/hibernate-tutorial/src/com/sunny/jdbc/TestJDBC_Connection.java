package com.sunny.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestJDBC_Connection {

	public static void main(String[] args) {
		
		String jdbcURL = "jdbc:mysql://localhost:3306/hibernate_student_tracker";
		String username= "sunny"; 
		String password= "sunny";
		
		try {
			Connection connection = DriverManager.getConnection(jdbcURL, username, password);
			
			System.out.println(DriverManager.getDriver(jdbcURL).getClass());
			
			System.out.println("Connection established");
			Statement stmt=connection.createStatement();  
			
			ResultSet rs=stmt.executeQuery("Select * from mysql.user"); 
			while(rs.next())
				System.out.println(rs.getNString("user"));  
			
			connection.close();
		}
		catch (Exception e) {
			System.err.println(e);
		}
	}
}