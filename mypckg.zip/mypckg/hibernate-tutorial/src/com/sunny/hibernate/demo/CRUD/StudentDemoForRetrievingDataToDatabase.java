package com.sunny.hibernate.demo.CRUD;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.sunny.hibernate.mapping.entityClass.StudentEntity;

public class StudentDemoForRetrievingDataToDatabase {
	
	public static void main(String[] args) {
		
		// Create Session Factory
		SessionFactory sessionFactory = new Configuration()
											.configure("hibernate.cfg.xml") // Same as we have in our project, can pass nothing if xml file name is exactly 'hibernate.cfg.xml'
											.addAnnotatedClass(StudentEntity.class)
											.buildSessionFactory();
		
		// Create session
		Session currentSession = sessionFactory.getCurrentSession();
		try {
			
			currentSession.beginTransaction();
			
			// retrieve student based on the id: primary key
			StudentEntity myStudent = currentSession.get(StudentEntity.class, 6);
			
			System.out.println("Get complete: " + myStudent);
			System.out.println("Get id: " + myStudent.getId_PK());
			System.out.println("Get name: " + myStudent.getFirstName() + " " + myStudent.getLastName());
			
			// commit the transaction
			currentSession.getTransaction().commit();
			
			System.out.println("Done!");
		}catch (Exception e) {
			System.err.println(e);
		}
		finally {
			currentSession.close();
			sessionFactory.close();
		}
	}
}