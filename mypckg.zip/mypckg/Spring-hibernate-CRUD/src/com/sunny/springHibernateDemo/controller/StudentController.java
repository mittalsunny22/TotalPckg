package com.sunny.springHibernateDemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sunny.springHibernateDemo.DAO.StudentDAO;
import com.sunny.springHibernateDemo.entity.StudentEntity;

@Controller
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	private StudentDAO studentDAO;

	@RequestMapping("/showFormForStudent")
	public String showForm() {
		return "student-form";
	} 
	
	@RequestMapping("/showStudents")
	//@RequestMapping("/")
	public String showStudents(Model model) {
		
		// Get students from DAO
		List<StudentEntity> students = studentDAO.getStudents();
		
		model.addAttribute("studentListFromDAO", students);
		
		return "student-list";
	}
} 