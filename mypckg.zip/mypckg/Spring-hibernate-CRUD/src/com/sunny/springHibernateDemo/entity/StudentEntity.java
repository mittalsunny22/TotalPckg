package com.sunny.springHibernateDemo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

// Below two annotations are required to map class to database Table
@Entity
@Table(name = "student")
public class StudentEntity {

	@Id // this annotation is additionally added to signify that this field is for primary key
	@Column(name = "id")
	private int id_PK;
	
	@Column(name = "first_name")
	private String firstName;
	
	@Column(name = "last_name")
	private String lastName;
	
	@Column(name = "email")
	private String email;
	
	public StudentEntity() {
	}

	public StudentEntity(String firstName, String lastName, String email) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}

	public int getId_PK() {
		return id_PK;
	}

	public void setId_PK(int id_PK) {
		this.id_PK = id_PK;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	// Overrided below method to print the whole object with values
	@Override
	public String toString() {
		return "StudentEntity [id_PK=" + id_PK + ", firstName=" + firstName + ", lastName=" + lastName + ", email="
				+ email + "]";
	}
}