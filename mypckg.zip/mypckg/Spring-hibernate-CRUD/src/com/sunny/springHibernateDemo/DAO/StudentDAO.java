package com.sunny.springHibernateDemo.DAO;

import java.util.List;

import com.sunny.springHibernateDemo.entity.StudentEntity;

public interface StudentDAO {
	
	public List<StudentEntity> getStudents();

}
