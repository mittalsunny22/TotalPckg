package com.sunny.dbTest;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestDbConnection
 */
@WebServlet("/TestDbConnection")
public class TestDbConnection extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		// Connection Details
		String jdbcURL = "jdbc:mysql://localhost:3306/hibernate_student_tracker";
		String username= "sunny"; 
		String password= "sunny";
		
		System.out.println("Starting....");
		
		// Writer to write on page instead of console
		PrintWriter writer = response.getWriter();
		
		// Make a connection
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			System.out.println("After driver class");	
			
			Connection connection = DriverManager.getConnection(jdbcURL, username, password);
			
			writer.println("Connection established");
			Statement stmt=connection.createStatement();  
			
			ResultSet rs=stmt.executeQuery("Select * from student"); 
			while(rs.next())
				writer.println(rs.getInt("id"));  
			
			connection.close();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e);
		}
	}

}
