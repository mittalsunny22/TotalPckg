package com.sunny.springDemo;

public interface Coach {

	public String getDailyWorkout();
	
}