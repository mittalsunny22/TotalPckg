package com.sunny.springDemo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ScopeDemoApp {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
				
		// get the bean from spring container
		Coach theCoach = context.getBean("thatSillyCoach", Coach.class);
		
		Coach theSecondCoach = context.getBean("thatSillyCoach", Coach.class);
		
		// check if both are same
		boolean result = (theCoach == theSecondCoach);
		
		System.out.println(result);
		
		// check Memory location
		System.out.println("1st coach : " + theCoach);
		System.out.println("2nd coach : " + theSecondCoach);
		
		//Close the context
		context.close();
	} 

}