package com.sunny.springDemo;

public interface FortuneService {
	
	public String getFortune();

}
