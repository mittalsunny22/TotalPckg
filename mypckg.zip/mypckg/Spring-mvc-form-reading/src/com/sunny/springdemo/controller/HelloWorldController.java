package com.sunny.springdemo.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
//We can also use @RequestMapping here as parent level mapping to remove ambiguity if two methods from different controllers have same mapping address. then address will change as parent mapping name/child mapping name. 
public class HelloWorldController {

	// Need a controller method to show very first page
	@RequestMapping("/")
	public String showFirstPage()
	{
		return "first-page";
	}
	
	// Need a controller method to show initial Form
	@RequestMapping("/showFormPage")
	public String showForm()
	{
		return "form-page";
	}
	
	//Need a controller method to process the HTML form
	// Here /processForm will be same as we gave action name in form in jsp file.
	@RequestMapping("/processForm")
	public String processHTML()
	{
		//Once the form is processed, user will see final confirm page.
		return "confirmation-page";
	}
	
	/**
	 *   Either we will go with upper approach where we are just printing data without involving model
	 *           OR 
	 *   We will use below method to modify/alter data from request and pass it to model.
	 */
		//Need a controller method to process the HTML form
		// Here /processForm will be same as we gave action name in form in jsp file.
		@RequestMapping("/processFormFromModel")
		public String processHTML_fromModel(HttpServletRequest request, Model model)
		{
			//read the request parameter from HTML page
			String name = request.getParameter("studentName1"); // OR we can use '@RequestParam("studentName1") String name' in parameter in place of 'HttpServletRequest request' and directly use name inside the method
			
			name = "Yehh !!!! " + name.toUpperCase();
		
			//	add updated message to Model, here we can give any name to the attribute and same name will be used in jsp while printing name.
			model.addAttribute("ANY_NAME", name); // here name will be bind with ANY_NAME, similarly we can have n number of attributes
			
			//Once the form is processed, user will see final confirm page.
			return "confirmation-page-message-from-model";
		}
}