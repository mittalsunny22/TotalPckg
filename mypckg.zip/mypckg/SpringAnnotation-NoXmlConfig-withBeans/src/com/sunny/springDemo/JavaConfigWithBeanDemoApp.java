package com.sunny.springDemo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class JavaConfigWithBeanDemoApp {

	public static void main(String[] args) {

		// read spring config java
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(JavaConfigWithBean.class);
		
		// get the bean from spring container
		Coach theCoach = context.getBean("swimCoach", Coach.class);
		
		// call a method on the bean
		System.out.println(theCoach.getDailyWorkout());
		
		System.out.println(theCoach.getDailyFortune());
				
		// close the context
		context.close();
	}
}