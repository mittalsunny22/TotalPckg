package com.sunny.springdemo.mvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

// @Controller inherits from @Component so it supports scanning feature
@Controller
public class HomeController {

	@RequestMapping("/")
	public String showMyPage()
	{
		// this will return view name which is jsp file name.
		return "main-menu";
	}
}
