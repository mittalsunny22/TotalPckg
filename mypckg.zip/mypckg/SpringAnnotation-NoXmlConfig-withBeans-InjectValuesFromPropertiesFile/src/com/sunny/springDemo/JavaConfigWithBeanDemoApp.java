package com.sunny.springDemo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class JavaConfigWithBeanDemoApp {

	public static void main(String[] args) {

		// read spring config java
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(JavaConfigWithBean.class);
		
		// get the bean from spring container
		Coach theCoach = context.getBean("swimCoach", Coach.class);
		
		//Now as we havenot added these new properties methods in Coach interface so we will take swimCoach class and call these methods.
		SwimCoach swimCoach = context.getBean("swimCoach", SwimCoach.class);
		
		System.out.println(swimCoach.getTeamName());
		System.out.println(swimCoach.getTeamPlayer());
		System.out.println(swimCoach.getTeamTest());
		
		// call a method on the bean
		System.out.println(theCoach.getDailyWorkout());
		
		System.out.println(theCoach.getDailyFortune());
			
		// close the context
		context.close();
	}
}